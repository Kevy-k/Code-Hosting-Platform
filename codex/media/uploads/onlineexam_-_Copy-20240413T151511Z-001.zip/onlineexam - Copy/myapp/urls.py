from django.urls import  path,include
from .import views
urlpatterns=[
    path('',views.index),
    path('h/',views.index),
    path('addp/',views.addcourse),
    path('ap/',views.listcourse),
    path('del/<int:id>/',views.delprogram),
    path('ed/<int:id>/',views.editcourse),
    path('qu/',views.table2),
    path('qu1/<int:id>/',views.addquestion),
    path('delq/<int:id>/',views.deletequestion),
    path('avqb/',views.adminviewqbank),
    path('shq/<int:qcode>/', views.adminviewqbank1),
    path('ur/',views.registration),
    path('als/',views.adminliststudents),

    path('apage/',views.showadminpage),
    path('upage/', views.showuserpage),
    path('log/',views.loginpage),

    path('sjc/',views.joincourse),
    path('joc/<int:id>/', views.newadmission),
    path('exam/',views.attendexam),
    path('sea/<int:id>/',views.startexam),
    path('ste/',views.continueexam),
    path('chp/', views.changepword),
    path('uchp/', views.userchangepword),





]