from django.contrib import admin
from myapp.models import course,qmaster,qsub,ureg,admission

# Register your models here.


class admincourse(admin.ModelAdmin):
    list_display = ('id','tcc','tcn','tdu','tsy','tfe','tmq','tpho')
admin.site.register(course,admincourse)

class admnqmaster(admin.ModelAdmin):
    list_display = ('id','qcode','tcc','tcn','nofq','pm')

admin.site.register(qmaster,admnqmaster)

class admqsub(admin.ModelAdmin):
    list_display = ('id','qcode','qno','question','opt1','opt2','opt3','opt4','ans',)

admin.site.register(qsub,admqsub)

admin.site.register(ureg)
admin.site.register(admission)
