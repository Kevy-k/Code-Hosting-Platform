from django.shortcuts import render,redirect
import pyttsx3
from django.db.models.functions import Coalesce
from django.db.models import Sum
from django.db.models import Max,Value
from django.db.models import F
from datetime import date
from myapp.models import course,qmaster,qsub,qtemp,ureg,admission
import random

# Create your views here.
def index(request):
    return render(request,"index.html")
def addcourse(request):
    if request.method == "POST":
        mcc = request.POST.get('cc')
        mcn = request.POST.get('cn')
        mdu = request.POST.get('du')
        msy = request.POST.get('sy')
        mfe = request.POST.get('fe')
        mmq = request.POST.get('mq')
        mpho = request.FILES['file']
        co = course(tcc=mcc, tcn=mcn, tdu=mdu, tsy=msy, tfe=mfe, tmq=mmq, tpho=mpho)
        co.save()
    return render(request,"adminaddcourse.html")
def listcourse(request):
    crec=course.objects.all()
    return render(request,"adminlistcourse.html",{"crec":crec})
def delprogram(request,id):
    course.objects.filter(id=id).delete()
    return redirect("/ap/")
def editcourse(request,id):
    if request.method=="POST":
        cc=request.POST.get('cc')
        cn=request.POST.get('cn')
        du=request.POST.get('du')
        sy=request.POST.get('sy')
        fe=request.POST.get('fe')
        mq=request.POST.get('mq')
        course.objects.filter(id=id).update(tcc=cc,tcn=cn,tdu=du,tsy=sy,tfe=fe,tmq=mq)
        return redirect("/ap/")
    mrec=course.objects.filter(id=id)
    for j in mrec:
      cc=j.tcc
      cn=j.tcn
      du=j.tdu
      sy=j.tsy
      fe=j.tfe
      mq=j.tmq
    return render(request,"admineditcourse.html",{"cc":cc,"cn":cn,"du":du,"sy":sy,"fe":fe,"mq":mq})

def table2(request):
    crec=course.objects.all()
    return render(request,"adminquest1.html",{"crec":crec})


def addquestion(request,id):
    request.session['subjectid']=id
    max_qcode =qmaster.objects.aggregate(max_qcode=Coalesce(Max('qcode'),Value(0)))['max_qcode']
    mcode = int(max_qcode) +1
    crec = course.objects.filter(id=id)
    for j in crec:
        ccode = j.tcc
        cname = j.tcn
    if request.method=="POST":
        if "s1" in request.POST:
            question = request.POST.get('question')
            opt1 = request.POST.get('t1')
            opt2= request.POST.get('t2')
            opt3 = request.POST.get('t3')
            opt4 = request.POST.get('t4')
            ans = request.POST.get('ans')
            qa=qtemp(qcode=mcode,qno=0,question =question,opt1 =opt1,opt2=opt2, opt3 =opt3,opt4 =opt4,ans = ans )
            qa.save()
        if "s2" in request.POST:
            qrec=qtemp.objects.all()
            sl=1
            for j in qrec:
                qa=qsub(qcode=j.qcode,qno=sl,question=j.question,opt1=j.opt1,opt2=j.opt2,opt3=j.opt3,opt4=j.opt4,ans=j.ans)
                qa.save()
                sl=int(sl)+1
            sl=sl-1
            pm=sl/2
            qm=qmaster(qcode=mcode,tcc=id,tcn=cname,nofq=sl,pm=pm)
            qm.save()
            qtemp.objects.all().delete()
            return redirect("/qu/")
    qrec=qtemp.objects.all()
    return render(request,"adminquest2.html",{"ccode":ccode,"cname":cname,"mcode":mcode,"qrec":qrec,"id":id})


def deletequestion(request,id):
    qtemp.objects.filter(id=id).delete()
    max_qcode = qmaster.objects.aggregate(max_qcode=Coalesce(Max('qcode'), Value(0)))['max_qcode']
    mcode = int(max_qcode) + 1
    qrec = qtemp.objects.all()
    id=request.session['subjectid']
    crec = course.objects.filter(id=id)
    for j in crec:
        ccode = j.tcc
        cname = j.tcn
    return render(request, "adminquest2.html",
                  {"ccode": ccode, "cname": cname, "mcode": mcode, "qrec": qrec, "id": id})

def registration(request):
    if request.method=="POST":
        fname = request.POST.get('fname')
        file = request.FILES['file']
        age = request.POST.get('age')
        gdr = request.POST.get('gender')
        add = request.POST.get('add')
        phn = request.POST.get('phn')
        eid = request.POST.get('eid')
        qul = request.POST.get('qul')
        usn = request.POST.get('usn')
        pasw = request.POST.get('pasw')
        re= ureg(fname=fname,file=file, age=age, gdr=gdr, add=add, phn=phn, eid=eid,qul=qul,usn=usn,pasw=pasw)
        re.save()
        return redirect("/h/")
    return render(request,"studentreg.html")



def adminviewqbank(request):
    qrec=qmaster.objects.all()
    return render(request,"adminlistquest1.html",{"qrec":qrec})

def adminviewqbank1(request,qcode):
    srec=qsub.objects.filter(qcode=qcode)
    return render(request,"adminlistquest2.html",{"srec":srec})


def adminliststudents(request):
    srec=ureg.objects.filter(rights='user')
    return render(request, "adminliststudent.html", {"srec": srec})

def loginpage(request):
    if request.method=="POST":
        u=request.POST.get('t1')
        p=request.POST.get('t2')
        urec=ureg.objects.filter(usn=u,pasw=p)
        if urec.exists():
            for j in urec:
                id=j.id
                n=j.fname
                r=j.rights
                ph=j.phn
                em=j.eid

            request.session['id']=id
            request.session['name']=n
            request.session['phone'] = ph
            request.session['email'] = em
            request.session['uname']=u
            request.session['pword']=p
            request.session['rights']=r
            if r=="admin":
                return redirect("/apage/")
            elif r=="user":
                return redirect("/upage/")
        else:
            engine=pyttsx3.init()
            msg="invalid user"
            engine.say(msg)
            engine.runAndWait()

    return render(request,"login.html")

def showuserpage(request):
    id=request.session['id']
    urec=ureg.objects.filter(id=id)
    for j in urec:
        name=j.fname
        photo=j.file

    return render(request,"userpage.html",{"name":name,"photo":photo})

def showadminpage(request):
    return render(request,"adminpanel.html")


def joincourse(request):
    id = request.session['id']
    urec = ureg.objects.filter(id=id)
    for j in urec:
        name = j.fname
        photo = j.file
    crec=course.objects.all()
    return render(request,"userjoincourse.html",{"crec":crec,"name":name,"photo":photo})


def newadmission(request,id):


    crec=course.objects.filter(id=id)
    for j in crec:
        cname=j.tcn
        dur=j.tdu
        fee=j.tfe
    if request.method=="POST":
        cno=request.POST.get('cno')
        sa=admission(uid=request.session['id'],uname=request.session['name'], cid=id,cname=cname,dur=dur,fee=fee,cardno=cno)
        sa.save()
        return redirect("/upage/")
    arec=admission.objects.filter(cid=id, uid=request.session['id'])
    if arec.exists():
        engine = pyttsx3.init()
        msg = "Already registered for this course join another thankyou"
        engine.say(msg)
        engine.runAndWait()
        return redirect("/upage/")
    else:
        return render(request,"paynow.html",{"fee":fee})

def attendexam(request):
    urec = ureg.objects.filter(id=request.session['id'])
    for j in urec:
        name = j.fname
        photo = j.file

    arec=admission.objects.filter(uid=request.session['id'])
    return render(request,"userattendexam.html",{"arec":arec,"name":name,"photo":photo})


def startexam(request ,id):
    arec=admission.objects.filter(id=id)
    for j in arec:
        subid=j.cid
    qlist=[]
    qrec=qmaster.objects.filter(tcc=subid)
    if qrec.exists():
        for j in qrec:
            qlist.append(j.qcode)
            s=j.tcn
            mx=j.nofq
            pm=j.pm
        qcode=random.choice(qlist)
        request.session['recordid'] = id
        request.session['qcode']=qcode
        request.session['qno']=1
        request.session['subid']=subid
        request.session['subname']=s
        request.session['mx'] = mx
        request.session['pm'] = pm
        request.session['score'] = 0
        return redirect("/ste/")
    return redirect("/upage/")

def continueexam(request):
    qcode = request.session['qcode']
    rid = request.session['recordid']
    mx = request.session['mx']
    pm = request.session['pm']

    if request.method=="POST":
        qno = request.session['qno']
        ans=request.POST.get('opt')
        print(qno)
        print(ans)
        arec=qsub.objects.filter(qcode=qcode,qno=qno)
        for j in arec:
            an=j.ans
        if int(ans)==int(an):
            s=request.session['score']
            s=s+1
            request.session['score']=s
        qno=qno+1
        if qno<=request.session['mx']:
            request.session['qno']=qno

        else:
            score=request.session['score']
            admission.objects.filter(id=rid).update(exstatus='Exam Over',maxmark=mx,passmark=pm,markobtained=score)
            return redirect("/exam/")


    qno = request.session['qno']
    course = request.session['subname']

    sid = request.session['id']
    sname = request.session['name']
    quest=qsub.objects.filter(qcode=qcode,qno=qno)
    for j in quest:
        qno=j.qno
        qname=j.question
        op1=j.opt1
        op2=j.opt2
        op3=j.opt3
        op4=j.opt4

    return render(request,"userexamtable.html",{"qno":qno,"qname":qname,"op1":op1,"op2":op2,"op3":op3,"op4":op4,"course":course,"sname":sname,"sid":sid,"mx":mx})


def changepword(request):
    if request.method=="POST":
        a=request.POST.get('t1')
        b=request.POST.get('t2')
        c=request.POST.get('t3')
        u=request.session['uname']
        p=request.session['pword']
        if p==a:
            if b==c:
                ureg.objects.filter(usn=u,pasw=a).update(pasw=b)
                return redirect('/log/')
            else:
                engine = pyttsx3.init()
                msg = "new password and retype password are not matching try again"
                engine.say(msg)
                engine.runAndWait()
        else:
            engine = pyttsx3.init()
            msg = "incorrect password try again"
            engine.say(msg)
            engine.runAndWait()
    return render(request,"adminchangepass.html")


def userchangepword(request):
    if request.method=="POST":
        a=request.POST.get('t1')
        b=request.POST.get('t2')
        c=request.POST.get('t3')
        u=request.session['uname']
        p=request.session['pword']
        if p==a:
            if b==c:
                ureg.objects.filter(usn=u,pasw=a).update(pasw=b)
                return redirect('/log/')
            else:
                engine = pyttsx3.init()
                msg = "new password and retype password are not matching try again"
                engine.say(msg)
                engine.runAndWait()
        else:
            engine = pyttsx3.init()
            msg = "incorrect password try again"
            engine.say(msg)
            engine.runAndWait()
    return render(request,"userchangepass.html")