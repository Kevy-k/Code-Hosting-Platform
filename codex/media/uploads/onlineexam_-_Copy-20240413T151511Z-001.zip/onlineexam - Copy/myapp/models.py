from django.db import models
from datetime import date

# Create your models here.

class course(models.Model):
    tcc=models.IntegerField()
    tcn=models.CharField(max_length=50)
    tdu=models.CharField(max_length=50)
    tsy=models.CharField(max_length=50)
    tfe=models.IntegerField()
    tmq=models.CharField(max_length=50)
    tpho=models.ImageField(upload_to='images/')

class qmaster(models.Model):
    qcode=models.IntegerField()
    tcc=models.CharField(max_length=50)
    tcn=models.CharField(max_length=50)
    nofq=models.IntegerField()
    pm=models.IntegerField(default=0)

class qsub(models.Model):
    qcode=models.IntegerField()
    qno=models.IntegerField()
    question=models.CharField(max_length=150)
    opt1=models.CharField(max_length=150)
    opt2=models.CharField(max_length=150)
    opt3=models.CharField(max_length=150)
    opt4=models.CharField(max_length=150)
    ans=models.IntegerField()


class qtemp(models.Model):
    qcode = models.IntegerField()
    qno = models.IntegerField()
    question = models.CharField(max_length=150)
    opt1 = models.CharField(max_length=150)
    opt2 = models.CharField(max_length=150)
    opt3 = models.CharField(max_length=150)
    opt4 = models.CharField(max_length=150)
    ans = models.IntegerField()

class  ureg(models.Model):
    fname = models.CharField(max_length=50)
    file = models.ImageField(upload_to='images/')
    age = models.IntegerField()
    gdr = models.CharField(max_length=10)
    add = models.CharField(max_length=50)
    phn = models.IntegerField()
    eid = models.CharField(max_length=30)
    qul = models.CharField(max_length=50)
    usn = models.CharField(max_length=30)
    pasw = models.CharField(max_length=20)
    rights=models.CharField(max_length=25, default='user')

class admission(models.Model):
    uid=models.IntegerField()
    uname=models.CharField(max_length=50)
    cid=models.IntegerField()
    cname=models.CharField(max_length=50)
    dur=models.CharField(max_length=50)
    fee=models.IntegerField()
    cardno=models.CharField(max_length=50)
    exstatus=models.CharField(max_length=25,default='Not Attended')
    maxmark=models.IntegerField(default=0)
    passmark = models.IntegerField(default=0)
    markobtained = models.IntegerField(default=0)

