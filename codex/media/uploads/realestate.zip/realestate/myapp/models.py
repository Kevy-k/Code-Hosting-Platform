from django.db import models
from datetime import date
class registration(models.Model):
    firstname=models.CharField(max_length=50)
    lastname=models.CharField(max_length=50)
    username=models.CharField(max_length=50)
    password=models.CharField(max_length=50)
    address=models.CharField(max_length=40)
    aadharnumber=models.IntegerField()
    pincode=models.CharField(max_length=30)
    place=models.CharField(max_length=20)
    location=models.CharField(max_length=20)
    code=models.IntegerField()
    phonenumber=models.IntegerField()
    email=models.CharField(max_length=15)
    rights=models.CharField(max_length=20 , default='NS')

class buildings(models.Model):
    sid=models.CharField(max_length=40)
    sname=models.CharField(max_length=40)
    ploc=models.CharField(max_length=40)
    tsqft=models.CharField(max_length=40)
    bsqft=models.CharField(max_length=40)
    nof=models.CharField(max_length=40)
    bcat=models.CharField(max_length=40)
    bimg=models.ImageField(upload_to='images/')
    backimg=models.ImageField(upload_to='images/')
    rimg=models.ImageField(upload_to='images/')
    limg=models.ImageField(upload_to='images/')
    iimg=models.ImageField(upload_to='images/')
    eprice=models.CharField(max_length=40)
    status=models.CharField(max_length=50,default='Not Sold')
    bid=models.IntegerField(default=0)
    bname=models.CharField(max_length=50,default='nil')
    cprice=models.IntegerField(default=0)

class userorder(models.Model):
    reqno=models.IntegerField()
    rdate = models.DateField(default=date.today)
    bid= models.IntegerField()
    bname = models.CharField(max_length=30)
    pid = models.IntegerField()
    location = models.CharField(max_length=30)
    price= models.IntegerField()
    sid = models.IntegerField()
    sname = models.CharField(max_length=30)
    qamt = models.IntegerField()
    status =models.CharField(max_length=50,default='New Request')
    pstatus=models.CharField(max_length=50,default='New Request')
    cardno=models.CharField(max_length=15, default='000')



# Create your models here.