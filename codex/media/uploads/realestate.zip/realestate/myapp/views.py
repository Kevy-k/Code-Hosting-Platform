from django.shortcuts import render,redirect
from django.http import  HttpResponse
from myapp.models import registration,buildings,userorder
from datetime import date

from django.db.models.functions import Coalesce
from django.db.models import Sum
from django.db.models import Max,Value
from django.db.models import F

# Create your views here.
import pyttsx3


def index(request):
    return render(request,"index.html")
def sellerreg(request):
    if request.method=="POST":
        a1=request.POST.get('fn')
        a2=request.POST.get('ln')
        a3=request.POST.get('username')
        a4=request.POST.get('password')
        a5=request.POST.get('address')
        a6=request.POST.get('ar')
        a7=request.POST.get('pincode')
        a8=request.POST.get('place')
        a9=request.POST.get('location')
        a10=request.POST.get('code')
        a11=request.POST.get('phone')
        a12=request.POST.get('email')
        urec = registration.objects.filter(username=a3)
        if urec.exists():
            msg="Sorry Duplication"
           # engine.say(msg)
           # engine.runAndWait()
            return render(request,"edu.html",{"msg":msg})
        else:
            ur=registration(firstname=a1,lastname=a2,username=a3,password=a4,address=a5,aadharnumber=a6,pincode=a7,place=a8,location=a9,code=a10,phonenumber=a11,email=a12)
            ur.save()
            msg = "Your Registration updated successfully"
            return render(request, "edu.html", {"msg": msg})
    return render(request,"sellerregistration.html")

def buyreg(request):
    if request.method == "POST":
        a1 = request.POST.get('fn')
        a2 = request.POST.get('ln')
        a3 = request.POST.get('username')
        a4 = request.POST.get('password')
        a5 = request.POST.get('address')
        a6 = request.POST.get('ar')
        a7 = request.POST.get('pincode')
        a8 = request.POST.get('place')
        a9 = request.POST.get('location')
        a10 = request.POST.get('code')
        a11 = request.POST.get('phone')
        a12 = request.POST.get('email')
        urec = registration.objects.filter(username=a3)
        if urec.exists():
            msg = "Sorry Duplication"
            return render(request, "edu.html", {"msg": msg})
        else:
            ur = registration(firstname=a1, lastname=a2, username=a3, password=a4, address=a5, aadharnumber=a6, pincode=a7,
                          place=a8, location=a9, code=a10, phonenumber=a11, email=a12,rights='Buyer')
            ur.save()
            msg = "Your Registration updated successfully"
            return render(request, "edu.html", {"msg": msg})
    return render(request, "buyerreg.html")

def loginfunction(request):
    if request.method=="POST":
        us=request.POST.get('u')
        ps=request.POST.get('p')
        urec=registration.objects.filter(username=us, password=ps)
        if urec.exists():
            for j in urec:
                id=j.id
                name=j.firstname
                ph=j.phonenumber
                r=j.rights

            request.session['id'] = id
            request.session['name'] = name
            request.session['phone'] = ph
            request.session['uname'] = us
            request.session['pword'] = ps
            request.session['rights'] =r

            if r=="admin":
                return redirect('/lap/')
            elif r=="Buyer":
                return redirect('/lbp/')
            elif r=="Seller":
                return redirect("/lsp/")
            elif r=="NS":
                msg="Wait your Application Under process"
                return render(request, "error.html", {"msg": msg})
            else:
                msg = "Sorry your Request Rejected.........."
                return render(request, "error.html", {"msg": msg})
        else:
            engine = pyttsx3.init()
            msg = "Sorry Invalid User"
            engine.say(msg)
            engine.runAndWait()
    return render(request,"login.html")

def sellerapproval(request):
    rec=registration.objects.filter(rights='NS')
    return render(request,"adminsellerapproval.html",{"rec":rec})

def selleraccept(request,id):
    registration.objects.filter(id=id).update(rights='Seller')
    return redirect("/aaprv/")

def loadsellerpage(request):
    n=request.session['name']
    return render(request, "sellerpage.html",{"n":n})

def loadadminpage(request):
    return render(request, "adminpage.html")
def sellereject(request,id):
    registration.objects.filter(id=id).update(rights='Reject')
    return redirect("/aaprv/")
def uploadsellingproperty(request):
    sid=request.session['id']
    sname=request.session['name']
    if request.method=="POST":
        a1 = request.POST.get('pl')
        a2 = request.POST.get('ts')
        a3 = request.POST.get('bs')
        a4 = request.POST.get('fl')
        a5 = request.POST.get('cat')
        a6 = request.FILES['file']
        a7= request.FILES['file1']
        a8 = request.FILES['file2']
        a9= request.FILES['file3']
        a10 = request.FILES['file4']
        a11= request.POST.get('price')
        sa=buildings(sid=sid,sname=sname,ploc=a1,tsqft=a2,bsqft=a3,nof=a4,bcat=a5,bimg=a6,backimg=a7,rimg=a8,limg=a9,iimg=a10,eprice=a11)
        sa.save()
        return redirect("/lsp/")
    return render(request,"uploadsellingp.html",{"sid":sid,"sname":sname})
def page(request):
    return render(request,"edu.html")
def uploadrentingproperty(request):
    return render(request,"uploadrentalp.html")

def loadbuyerpage(request):

    prec=buildings.objects.filter(status='Not Sold')
    return render(request, "userpage.html",{"prec":prec})

def moreimages(request,id):
    brec = buildings.objects.filter(id=id)
    prec = buildings.objects.filter(status='Not Sold')
    for j in brec:
        bimg=j.backimg
        rimg=j.rimg
        limg=j.limg
        iimg=j.iimg
    return render(request, "userpage.html", {"prec": prec,"bimg":bimg,"rimg":rimg,"limg":limg,"iimg":iimg})

def buyerrequest(request,id):
    cdate=date.today()
    brec=buildings.objects.filter(id=id)
    max_reqno =userorder.objects.aggregate(max_reqno=Coalesce( Max('reqno'),Value(0)))['max_reqno']
    mreqno=int(max_reqno)+1
    bid=request.session['id']
    bname=request.session['name']

    for j in brec:
        pid=j.id
        lo=j.ploc
        price=j.eprice
        sid=j.sid
        sname=j.sname
    if request.method=="POST":
        qp=request.POST.get('qprice')
        usa=userorder(reqno=mreqno,rdate=cdate,bid=bid,bname=bname,pid=pid,location=lo,price=price,sid=sid,sname=sname,qamt=qp)
        usa.save()
        return redirect("/lbp/")

    return render(request,"buyerreq.html",{"mreqno":mreqno,"cdate":cdate,"bid":bid,"bname":bname,"pid":pid,"lo":lo,"price":price,"sid":sid,"sname":sname})

def sellerviewbuyerrequest(request):
    rec=userorder.objects.filter(sid=request.session['id'],status='New Request')
    return render(request,"viewpropertyrequest.html",{"rec":rec})

def selleramountapproval(request,id):
     userorder.objects.filter(id=id).update(status='Accept',pstatus='Pay Now')
     return redirect('/lsp/')


def selleramountreject(request, id):
    userorder.objects.filter(id=id).update(status='Reject',pstatus='Not Feasible')
    return redirect('/lsp/')


def viewbuyerrequeststatus(request):
    rec= userorder.objects.filter(bid=request.session['id'])
    return render(request, "buyerviewpropertyrequeststatus.html", {"rec": rec})

def payment(request, id):
    urec=userorder.objects.filter(id=id)
    for j in urec:
        st=j.status
        ps=j.pstatus
        pid=j.pid
    if request.method=="POST":
        bname= request.POST.get('name')
        cardno= request.POST.get('card')
        ex= request.POST.get('expiry')
        cvc= request.POST.get('cvv')
        userorder.objects.filter(id=id).update(pstatus='paid',cardno=cardno)
        buildings.objects.filter(id=pid).update(status='sold')
    if st=='Accept' and ps=='Pay Now':
        return render(request, "payment.html")
    return redirect("/vbrs/")


def transferprop(request):
    prec=userorder.objects.filter(sid=request.session['id'], status='Accept', pstatus='paid')
    return render(request,"transfer.html",{"prec":prec})

def transferprop1(request,id):
    urec = userorder.objects.filter(id=id)
    for j in urec:
        bid = j.bid
        bn = j.bname
        pid = j.pid
        p=j.qamt
    userorder.objects.filter(id=id).update(status='Transfered')
    buildings.objects.filter(id=bid).update(bid=bid,bname=bn,cprice=p)
    return redirect("/trns/")

def soldhistory(request):
    prec = userorder.objects.filter(sid=request.session['id'], status='Transfered')
    return render(request, "soldhistory.html", {"prec": prec})


def buildinglist(request):
    prec = buildings.objects.filter(bid=request.session['id'])
    return render(request,"building.html",{"prec":prec})


def changepassword(request):
    return render(request,"change.html")


def changepassword(request):
    return render(request,"change.html")

def adminviewproperty(request):
    rec=buildings.objects.all()
    return render(request,"adminviewproperty.html",{"rec":rec})
def adminviewp(request,id):
    rec = buildings.objects.filter(id=id)
    for j in rec:
        f=j.bimg
        b=j.backimg
        r=j.rimg
        l=j.limg
        i=j.iimg
    return render(request, "adminviewphoto.html", {"f":f,"b":b,"r":r,"l":l,"i":i})