from django.contrib import admin
from myapp.models import buildings,registration,userorder

# Register your models here.
admin.site.register(buildings)
admin.site.register(registration)
admin.site.register(userorder)
