from django.urls import path
from . import views
urlpatterns=[
    path('',views.index),
    path('p/',views.index),
    path('re/',views.sellerreg),
    path('by/',views.buyreg),
    path('lg/',views.loginfunction),
    path('aaprv/',views.sellerapproval),
    path('ap/<int:id>/',views.selleraccept),
    path('rj/<int:id>/',views.sellereject),
    path('lsp/',views.loadsellerpage),
    path('usp/',views.uploadsellingproperty),
    path('urp/',views.uploadrentingproperty),
    path('lap/',views.loadadminpage),
    path('lbp/', views.loadbuyerpage),
    path('brq/<int:id>/',views.buyerrequest),
    path('vbr/',views.sellerviewbuyerrequest),
    path('apamt/<int:id>/',views.selleramountapproval),
    path('rjamt/<int:id>/',views.selleramountreject),
    path('vbrs/',views.viewbuyerrequeststatus),
    path('upay/<int:id>/',views.payment),
    path('trns/',views.transferprop),
    path('tpr/<int:id>/',views.transferprop1),
    path('sldh/',views.soldhistory),
    path('bli/', views.buildinglist),
    path('cpass/',views.changepassword),
    path('cpd/',views.changepassword),
    path('mr/<int:id>/',views.moreimages),
    path('avp/',views.adminviewproperty),
    path('photo/<int:id>/',views.adminviewp),





]